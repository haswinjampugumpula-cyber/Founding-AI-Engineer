# Website Cloner Agent

An AI agent that takes a public website URL, analyzes its layout/content/design,
generates a **new** Next.js + TypeScript + Tailwind frontend that recreates it,
validates and auto-fixes the generated code, serves a local live preview, and
lets you keep editing it with plain-English instructions.

Built for the "Founding AI Engineer" take-home assignment. Runs entirely
locally — no hosting required.

---

## Setup

**Requirements:** Node.js ≥ 18.18, npm, an Anthropic API key.

```bash
git clone <this-repo>
cd website-cloner-agent
npm install
cp .env.example .env
# edit .env and set ANTHROPIC_API_KEY=sk-ant-...

npm run dev       # starts the control panel at http://localhost:4000
```

Open `http://localhost:4000`, paste a public URL, click **Analyze**, then
**Generate**. The first generation takes a minute or two (an `npm install`
runs inside the newly generated project). Once the preview is ready it loads
in the iframe on the right; use the chat box at the bottom-left to keep
modifying it ("make the navbar sticky", "add a testimonials section", "change
the primary color to blue", …).

Each session's generated project also stands on its own — you can `cd` into
it and run it independently:

```bash
cd generated-sites/<session-id>
npm install   # already done by the agent, but harmless to re-run
npm run dev
```

For production usage, set `npm run build && npm start` instead of `npm run dev`.

---

## Architecture

See [ARCHITECTURE.md](./ARCHITECTURE.md) for the full pipeline diagram and a
file-by-file breakdown. In short:

```
URL → Analysis (scraper.ts) → Generation (codegen.ts, Claude tool-call)
    → Validation/Auto-fix loop (validator.ts, Claude tool-call)
    → Local Preview (previewManager.ts spawns `next dev`)
    → Modification (modifier.ts, Claude tool-call) → back into Validation
```

The **orchestrator** (this repo's own server + control-panel UI) is a small
Express + vanilla-JS app. The **output** of the agent — what actually gets
graded as "the frontend" — is a separate, real Next.js/TypeScript/Tailwind
project generated per session under `generated-sites/<id>/`.

---

## Technologies / models used

- **Orchestrator:** Node.js, Express, TypeScript, `cheerio` (HTML parsing),
  `axios` (HTTP), vanilla HTML/JS + Tailwind CDN for the control panel (no
  build step needed for the tool itself).
- **Generated output:** Next.js 14 (App Router), React 18, TypeScript,
  Tailwind CSS.
- **AI model:** Claude (`claude-sonnet-5` by default, configurable via
  `ANTHROPIC_MODEL`), called through `@anthropic-ai/sdk` using **forced tool
  calls** (`tool_choice: {type: "tool", name: "write_project_files"}`) so the
  model always returns structured `{path, content}[]` file lists instead of
  prose that would need fragile parsing.

---

## Key implementation decisions

- **Static HTML/CSS analysis, not a headless browser.** `scraper.ts` fetches
  the page's server-rendered HTML plus up to 5 linked stylesheets and parses
  them with `cheerio`. This is fast, has no extra system dependencies, and
  works for the large majority of content/marketing sites. The trade-off is
  explicit: it's recorded as a warning in the analysis (surfaced in the UI and
  fed into the generation prompt) that computed/post-JS styles and
  client-rendered content aren't visible. A natural upgrade path (see
  Limitations) is swapping in Playwright for computed-style + screenshot
  analysis.
- **Boilerplate is hand-written, not AI-generated.** `package.json`,
  `next.config.js`, `tsconfig.json`, `tailwind.config.ts`,
  `postcss.config.js`, and `app/layout.tsx` are a fixed template
  (`templates/nextjs-base/`) copied into every session. Claude only ever
  generates `app/page.tsx`, `app/components/*.tsx`, and `app/globals.css`.
  This is both a **reliability** decision (framework plumbing can't be
  subtly broken by a generation) and a **cost** decision (fewer tokens spent
  regenerating identical boilerplate on every run).
- **Colors/typography as Tailwind arbitrary values, not a themed config.**
  The prompt asks Claude to reproduce the extracted palette directly as
  `bg-[#0f172a]`-style arbitrary-value classes rather than trying to patch
  `tailwind.config.ts` at runtime. This avoids a whole class of build errors
  from malformed dynamic Tailwind config and keeps the diff for a
  color-change modification small and easy to reason about.
- **A typecheck-first validation loop, with full `next build` optional.**
  `tsc --noEmit` catches the overwhelming majority of AI-generated mistakes
  (missing imports, bad JSX, wrong prop types) in a few seconds, which keeps
  the fix loop fast and cheap. A full `next build` (slower, catches more) is
  exposed as a separate on-demand endpoint (`POST /api/sessions/:id/build-check`)
  rather than run on every iteration.
- **Errors are fed back to the model as structured tool-call context, not
  re-prompted from scratch.** `fixFiles()` sends the current AI-authored
  files plus the raw compiler output and asks for a minimal patch, bounded
  by `MAX_FIX_ATTEMPTS` (default 3) so a persistently broken generation
  degrades gracefully (preview still starts; remaining errors are logged)
  instead of looping forever or blocking the whole pipeline.
- **Sessions are in-memory, not persisted.** This is a local MVP tool for one
  operator at a time; restarting the server clears sessions (the generated
  project files on disk under `generated-sites/` survive, though).

---

## Limitations

- No headless browser / JS execution during analysis, so single-page
  applications that render everything client-side will analyze poorly (this
  is surfaced as a warning in the UI rather than failing silently).
- Color/typography extraction is a static, regex-based pass over CSS text —
  it does not resolve CSS custom properties, computed cascade values, or
  imported/`@import`-ed stylesheets beyond the first hop.
- Visual accuracy is "reasonably close," not pixel-perfect: layout is
  recreated from structure + text + color/font signals, not from a rendered
  screenshot diffed against the output.
- The fix-retry loop only runs `tsc --noEmit` automatically; a passing
  typecheck does not guarantee a passing `next build` or runtime-correct
  page (use the optional build-check endpoint for extra confidence).
- Only tested against three sample sites; no automated regression test suite
  is included given the 48-hour scope.

---

## Technical discussion (anticipated questions)

**How you would reduce AI/API costs:** cache analyses for a given URL;
reuse a single generation across near-duplicate requests; keep the
boilerplate hand-written (already done); prefer the cheap `tsc --noEmit`
check over `next build` in the hot loop (already done); send only trimmed
analysis JSON to the model rather than raw HTML (already done); consider a
cheaper model for the fix loop (usually smaller diffs) and reserve the
larger model for the initial generation.

**How you would scale the system:** move sessions out of in-memory storage
into Redis/Postgres; run each generated project's install/build/dev-server
in an isolated container or serverless sandbox instead of local child
processes; queue generation/fix jobs instead of running them inline in the
request; put the preview behind a reverse proxy per session instead of
raw `localhost:<port>` iframes.

**What you would improve with more development time:** headless-browser
based analysis (Playwright) for computed styles and a real screenshot,
which would also enable a vision-based visual-diff feedback loop; streaming
the generation/fix tool calls token-by-token into the log console instead of
polling; a diff view before applying a modification; automated visual
regression tests against the three evaluation sites.
