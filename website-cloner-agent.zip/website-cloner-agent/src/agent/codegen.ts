import fs from "fs-extra";
import path from "path";
import { getClaudeClient, MODEL, estimateCostUsd } from "./claudeClient";
import { GeneratedFile, SiteAnalysis } from "./types";

const TEMPLATE_DIR = path.join(__dirname, "..", "..", "templates", "nextjs-base");

const WRITE_FILES_TOOL = {
  name: "write_project_files",
  description:
    "Write the set of files that make up the generated Next.js (App Router, TypeScript, Tailwind CSS) frontend for the site under app/. Only include files you are creating or changing.",
  input_schema: {
    type: "object" as const,
    properties: {
      files: {
        type: "array" as const,
        description: "Files to write, relative to the project root.",
        items: {
          type: "object" as const,
          properties: {
            path: {
              type: "string" as const,
              description:
                "Path relative to project root, e.g. 'app/page.tsx' or 'app/components/Hero.tsx'.",
            },
            content: {
              type: "string" as const,
              description: "Full file contents (TypeScript/TSX or CSS).",
            },
          },
          required: ["path", "content"],
        },
      },
      summary: {
        type: "string" as const,
        description: "One or two sentences describing what was generated.",
      },
    },
    required: ["files"],
  },
};

function buildSystemPrompt(): string {
  return `You are a senior frontend engineer inside an automated website-cloning agent.
Given a structured analysis of a public website's layout, text, colors, and typography,
you generate a NEW, original Next.js 14 (App Router) + TypeScript + Tailwind CSS
frontend that recreates the look, structure and content of that site as closely as
reasonably possible. You are NOT embedding or copying the original site's code —
you write fresh React components.

Hard constraints:
- Use ONLY Next.js App Router conventions. You may write: app/page.tsx, app/globals.css,
  and any number of files under app/components/*.tsx.
- Do not write package.json, next.config.js, tailwind.config.ts, tsconfig.json, or
  app/layout.tsx — those already exist and must not be overwritten.
- app/page.tsx must be a default-exported React Server Component (no "use client"
  unless a component genuinely needs interactivity, e.g. a mobile nav toggle — in
  that case put ONLY that interactive piece in its own small client component file
  starting with "use client").
- Style everything with Tailwind utility classes. Reproduce the extracted color
  palette using arbitrary-value Tailwind classes, e.g. bg-[#0f172a], text-[#f8fafc],
  border-[#e2e8f0]. Reproduce approximate font sizes/weights and border radii the
  same way when useful, e.g. text-[15px], rounded-[10px].
- Use next/image is NOT required; plain <img> tags with the original absolute image
  URLs (given in the analysis) are fine and preferred for reliability. Always include
  a meaningful alt attribute.
- Recreate: header/nav (with the real nav link text and hrefs), hero section, the
  content sections in the analysis (in order), and the footer (with real footer
  links). Use the actual extracted text content rather than placeholder lorem ipsum
  wherever text was captured.
- Make it responsive (mobile-first, then sm:/md:/lg: breakpoints) and reasonably
  accessible (semantic tags, alt text, visible focus states).
- Keep components small and reusable; avoid one giant file when the analysis has
  several distinct sections.
- Write clean, readable, idiomatic TypeScript/TSX. No TODOs, no placeholder comments
  claiming something is "not implemented".
- app/globals.css should only contain @tailwind directives plus small, genuinely
  necessary global rules (e.g. base font-family via a CSS variable). Do not redefine
  Tailwind's reset.

Always respond by calling the write_project_files tool exactly once with the
complete set of files. Do not include any other commentary outside the tool call.`;
}

function buildUserPrompt(analysis: SiteAnalysis): string {
  // Trim the analysis to keep the prompt focused and cost-aware.
  const trimmed = {
    sourceUrl: analysis.sourceUrl,
    title: analysis.title,
    metaDescription: analysis.metaDescription,
    nav: analysis.nav.slice(0, 12),
    footerLinks: analysis.footerLinks.slice(0, 12),
    sections: analysis.sections.slice(0, 12),
    images: analysis.images.slice(0, 16),
    designTokens: analysis.designTokens,
    warnings: analysis.warnings,
  };

  return `Here is the structured analysis of the website to recreate:

${JSON.stringify(trimmed, null, 2)}

Generate the Next.js App Router files now via the write_project_files tool.`;
}

export interface CodegenResult {
  files: GeneratedFile[];
  summary?: string;
  usage: { inputTokens: number; outputTokens: number };
  estimatedCostUsd: number;
}

/** Calls Claude to generate the initial set of page/component files. */
export async function generateSiteFiles(
  analysis: SiteAnalysis
): Promise<CodegenResult> {
  const client = getClaudeClient();
  const response = await client.messages.create({
    model: MODEL,
    max_tokens: 8000,
    system: buildSystemPrompt(),
    tools: [WRITE_FILES_TOOL],
    tool_choice: { type: "tool", name: "write_project_files" },
    messages: [{ role: "user", content: buildUserPrompt(analysis) }],
  });

  const toolUse = response.content.find((b) => b.type === "tool_use");
  if (!toolUse || toolUse.type !== "tool_use") {
    throw new Error("Model did not return a write_project_files tool call.");
  }
  const input = toolUse.input as { files: GeneratedFile[]; summary?: string };

  const usage = {
    inputTokens: response.usage.input_tokens,
    outputTokens: response.usage.output_tokens,
  };

  return {
    files: input.files,
    summary: input.summary,
    usage,
    estimatedCostUsd: estimateCostUsd(usage),
  };
}

/** Copies the hand-written base scaffold into a fresh project directory. */
export async function scaffoldProject(projectDir: string): Promise<void> {
  await fs.ensureDir(projectDir);
  await fs.copy(TEMPLATE_DIR, projectDir, {
    filter: (src) => !src.endsWith("README-template-note.md"),
  });
}

/** Patches the layout.tsx title/description placeholders with real site metadata. */
export async function patchLayoutMetadata(
  projectDir: string,
  analysis: SiteAnalysis
): Promise<void> {
  const layoutPath = path.join(projectDir, "app", "layout.tsx");
  let content = await fs.readFile(layoutPath, "utf-8");
  const safeTitle = (analysis.title || "Cloned Site").replace(/"/g, '\\"');
  const safeDesc = (analysis.metaDescription || "Generated by Website Cloner Agent").replace(
    /"/g,
    '\\"'
  );
  content = content
    .replace("__SITE_TITLE__", safeTitle)
    .replace("__SITE_DESCRIPTION__", safeDesc);
  await fs.writeFile(layoutPath, content, "utf-8");
}

/** Writes a list of generated files into the project directory (creating dirs as needed). */
export async function writeFiles(
  projectDir: string,
  files: GeneratedFile[]
): Promise<void> {
  for (const file of files) {
    const normalized = file.path.replace(/^\/+/, "");
    // Guard against path traversal from model output.
    const target = path.join(projectDir, normalized);
    if (!target.startsWith(path.resolve(projectDir))) {
      throw new Error(`Refusing to write outside project directory: ${file.path}`);
    }
    await fs.ensureDir(path.dirname(target));
    await fs.writeFile(target, file.content, "utf-8");
  }
}
