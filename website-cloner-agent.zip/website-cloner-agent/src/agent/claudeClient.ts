import Anthropic from "@anthropic-ai/sdk";

let client: Anthropic | null = null;

export function getClaudeClient(): Anthropic {
  if (!client) {
    const apiKey = process.env.ANTHROPIC_API_KEY;
    if (!apiKey) {
      throw new Error(
        "ANTHROPIC_API_KEY is not set. Copy .env.example to .env and add your key."
      );
    }
    client = new Anthropic({ apiKey });
  }
  return client;
}

export const MODEL = process.env.ANTHROPIC_MODEL || "claude-sonnet-5";

// A rough, best-effort cost estimate for the "cost awareness" evaluation
// criterion. Pricing changes over time; this is intentionally approximate
// and only used to log an indicative number, never billed on.
const APPROX_INPUT_COST_PER_MTOK = 3; // USD
const APPROX_OUTPUT_COST_PER_MTOK = 15; // USD

export interface UsageTotals {
  inputTokens: number;
  outputTokens: number;
}

export function estimateCostUsd(usage: UsageTotals): number {
  return (
    (usage.inputTokens / 1_000_000) * APPROX_INPUT_COST_PER_MTOK +
    (usage.outputTokens / 1_000_000) * APPROX_OUTPUT_COST_PER_MTOK
  );
}
