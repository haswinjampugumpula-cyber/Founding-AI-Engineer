import { ChildProcess, spawn } from "child_process";
import getPort from "get-port";
import treeKill from "tree-kill";

const rangeStart = Number(process.env.PREVIEW_PORT_RANGE_START || 4100);

const processes = new Map<string, ChildProcess>();

/** Finds a free TCP port in the configured preview range for a new session's dev server. */
export async function allocatePreviewPort(): Promise<number> {
  return getPort({ port: portRange() });
}

function portRange(): number[] {
  const ports: number[] = [];
  for (let p = rangeStart; p < rangeStart + 200; p++) ports.push(p);
  return ports;
}

/**
 * Starts `next dev` for a generated project on the given port. Resolves once the
 * dev server has printed its "ready" line (or after a timeout), so the caller can
 * safely point an iframe at it.
 */
export function startPreview(
  sessionId: string,
  projectDir: string,
  port: number,
  onLog: (line: string) => void
): Promise<ChildProcess> {
  return new Promise((resolve, reject) => {
    stopPreview(sessionId); // in case one is already running for this session

    const child = spawn("npx", ["next", "dev", "-p", String(port)], {
      cwd: projectDir,
      env: { ...process.env, PORT: String(port) },
      shell: process.platform === "win32",
    });

    processes.set(sessionId, child);

    let resolved = false;
    const readyTimeout = setTimeout(() => {
      if (!resolved) {
        resolved = true;
        resolve(child); // don't block forever; UI will retry loading the iframe
      }
    }, 20000);

    const handleChunk = (data: Buffer) => {
      const text = data.toString();
      onLog(text.trim());
      if (!resolved && /ready in|started server/i.test(text)) {
        resolved = true;
        clearTimeout(readyTimeout);
        resolve(child);
      }
    };

    child.stdout?.on("data", handleChunk);
    child.stderr?.on("data", handleChunk);

    child.on("error", (err) => {
      if (!resolved) {
        resolved = true;
        clearTimeout(readyTimeout);
        reject(err);
      }
    });

    child.on("exit", (code) => {
      onLog(`[preview server exited with code ${code}]`);
      processes.delete(sessionId);
    });
  });
}

export function stopPreview(sessionId: string): void {
  const child = processes.get(sessionId);
  if (child && child.pid) {
    treeKill(child.pid, "SIGTERM");
    processes.delete(sessionId);
  }
}

export function stopAllPreviews(): void {
  for (const id of Array.from(processes.keys())) stopPreview(id);
}
