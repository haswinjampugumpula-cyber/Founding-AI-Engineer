import fs from "fs-extra";
import { analyzeSite } from "./scraper";
import {
  generateSiteFiles,
  patchLayoutMetadata,
  scaffoldProject,
  writeFiles,
} from "./codegen";
import {
  buildProject,
  fixFiles,
  installDependencies,
  typecheckProject,
} from "./validator";
import { applyModification } from "./modifier";
import { allocatePreviewPort, startPreview, stopPreview } from "./previewManager";
import { log, setStatus } from "./session";
import { AgentSession, GeneratedFile } from "./types";

const MAX_FIX_ATTEMPTS = Number(process.env.MAX_FIX_ATTEMPTS || 3);

function filesMapToArray(session: AgentSession): GeneratedFile[] {
  return Array.from(session.files.entries()).map(([p, content]) => ({ path: p, content }));
}

function applyFilesToSession(session: AgentSession, files: GeneratedFile[]): void {
  for (const f of files) session.files.set(f.path, f.content);
}

/** Step 1: fetch + analyze the target URL. */
export async function runAnalysis(session: AgentSession): Promise<void> {
  setStatus(session, "analyzing");
  log(session, "step", `Fetching and analyzing ${session.url} ...`);
  try {
    const analysis = await analyzeSite(session.url);
    session.analysis = analysis;
    setStatus(session, "analyzed");
    log(
      session,
      "success",
      `Analysis complete: ${analysis.sections.length} sections, ${analysis.images.length} images, ${analysis.designTokens.colors.length} colors detected.`
    );
    for (const w of analysis.warnings) log(session, "warn", w);
  } catch (err: any) {
    setStatus(session, "error");
    session.lastError = err.message;
    log(session, "error", `Analysis failed: ${err.message}`);
    throw err;
  }
}

/** Step 2-4: generate the Next.js project, install deps, typecheck/build, auto-fix on failure. */
export async function runGeneration(session: AgentSession): Promise<void> {
  if (!session.analysis) throw new Error("Run analysis before generation.");
  setStatus(session, "generating");
  log(session, "step", "Scaffolding base Next.js project...");
  await scaffoldProject(session.projectDir);
  await patchLayoutMetadata(session.projectDir, session.analysis);

  log(session, "step", "Asking Claude to generate the frontend from the analysis...");
  const result = await generateSiteFiles(session.analysis);
  applyFilesToSession(session, result.files);
  await writeFiles(session.projectDir, result.files);
  log(
    session,
    "success",
    `Generated ${result.files.length} files (~$${result.estimatedCostUsd.toFixed(
      4
    )} est. API cost). ${result.summary || ""}`
  );

  log(session, "step", "Installing dependencies (npm install)... this can take a minute.");
  const install = await installDependencies(session.projectDir);
  if (!install.success) {
    setStatus(session, "error");
    session.lastError = "npm install failed";
    log(session, "error", `npm install failed:\n${install.output.slice(-1500)}`);
    throw new Error("npm install failed");
  }
  log(session, "success", "Dependencies installed.");

  await validateAndFixLoop(session);
  await launchPreview(session);
}

async function validateAndFixLoop(session: AgentSession): Promise<void> {
  setStatus(session, "validating");
  session.fixAttempts = 0;

  while (true) {
    log(session, "step", "Type-checking generated code...");
    const check = await typecheckProject(session.projectDir);
    if (check.success) {
      log(session, "success", "Type-check passed.");
      return;
    }

    log(session, "warn", `Type-check found issues:\n${check.output.slice(-1200)}`);

    if (session.fixAttempts >= MAX_FIX_ATTEMPTS) {
      log(
        session,
        "error",
        `Gave up after ${MAX_FIX_ATTEMPTS} automatic fix attempts. The preview may still partially work; manual fixes may be needed.`
      );
      return; // don't hard-fail the whole run — still try to launch the preview
    }

    session.fixAttempts += 1;
    setStatus(session, "fixing");
    log(
      session,
      "step",
      `Attempt ${session.fixAttempts}/${MAX_FIX_ATTEMPTS}: asking Claude to fix the build errors...`
    );

    if (!session.analysis) throw new Error("Missing analysis during fix loop.");
    const fix = await fixFiles(session.analysis, filesMapToArray(session), check.output);
    applyFilesToSession(session, fix.files);
    await writeFiles(session.projectDir, fix.files);
    log(
      session,
      "info",
      `Applied fix (~$${fix.estimatedCostUsd.toFixed(4)} est. API cost): ${
        fix.explanation || "no explanation provided"
      }`
    );
    setStatus(session, "validating");
  }
}

/** Optional, slower full production build check (not run by default in the auto loop). */
export async function runFullBuildCheck(session: AgentSession): Promise<boolean> {
  log(session, "step", "Running full `next build` validation...");
  const build = await buildProject(session.projectDir);
  if (build.success) {
    log(session, "success", "Production build succeeded.");
  } else {
    log(session, "warn", `Production build reported issues:\n${build.output.slice(-1500)}`);
  }
  return build.success;
}

export async function launchPreview(session: AgentSession): Promise<void> {
  setStatus(session, "starting_preview");
  const port = await allocatePreviewPort();
  log(session, "step", `Starting local preview dev server on port ${port}...`);
  const child = await startPreview(session.id, session.projectDir, port, (line) =>
    log(session, "info", line)
  );
  session.previewPort = port;
  session.previewProcessPid = child.pid;
  setStatus(session, "ready");
  log(session, "success", `Preview ready at http://localhost:${port}`);
}

export async function runModification(
  session: AgentSession,
  instruction: string
): Promise<void> {
  setStatus(session, "modifying");
  log(session, "step", `Applying modification: "${instruction}"`);
  const result = await applyModification(session.analysis, filesMapToArray(session), instruction);
  applyFilesToSession(session, result.files);
  await writeFiles(session.projectDir, result.files);
  log(
    session,
    "success",
    `Modification applied (~$${result.estimatedCostUsd.toFixed(4)} est. API cost): ${
      result.summary || ""
    }`
  );

  await validateAndFixLoop(session);
  setStatus(session, "ready");
  log(session, "success", "Preview will hot-reload with the change (Next.js dev server watches the files).");
}

export async function teardownSession(session: AgentSession): Promise<void> {
  stopPreview(session.id);
  await fs.remove(session.projectDir).catch(() => {});
}
