import path from "path";
import { nanoid } from "nanoid";
import { AgentLogEntry, AgentLogLevel, AgentSession, SessionStatus } from "./types";

const sessions = new Map<string, AgentSession>();

const GENERATED_ROOT = path.join(__dirname, "..", "..", "generated-sites");

export function createSession(url: string): AgentSession {
  const id = nanoid(10);
  const session: AgentSession = {
    id,
    url,
    status: "idle",
    files: new Map(),
    projectDir: path.join(GENERATED_ROOT, id),
    logs: [],
    createdAt: Date.now(),
    updatedAt: Date.now(),
    fixAttempts: 0,
  };
  sessions.set(id, session);
  return session;
}

export function getSession(id: string): AgentSession | undefined {
  return sessions.get(id);
}

export function requireSession(id: string): AgentSession {
  const s = sessions.get(id);
  if (!s) throw new Error(`Unknown session: ${id}`);
  return s;
}

export function setStatus(session: AgentSession, status: SessionStatus): void {
  session.status = status;
  session.updatedAt = Date.now();
}

export function log(
  session: AgentSession,
  level: AgentLogLevel,
  message: string
): AgentLogEntry {
  const entry: AgentLogEntry = { ts: Date.now(), level, message };
  session.logs.push(entry);
  if (session.logs.length > 500) session.logs.shift();
  session.updatedAt = Date.now();
  return entry;
}

export function listSessions(): AgentSession[] {
  return Array.from(sessions.values()).sort((a, b) => b.createdAt - a.createdAt);
}
