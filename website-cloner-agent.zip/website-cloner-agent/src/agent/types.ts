// Shared types used across the agent pipeline.

export interface NavLink {
  text: string;
  href: string;
}

export interface SectionSummary {
  tag: string; // e.g. "header", "section", "footer"
  heading?: string;
  headingLevel?: number;
  text: string; // truncated representative text content
  imageCount: number;
  imageAlts: string[];
  hasForm: boolean;
  listItemCount: number;
  buttonLabels: string[];
}

export interface ImageAsset {
  src: string;
  alt: string;
  width?: number;
  height?: number;
}

export interface DesignTokens {
  colors: {
    hex: string;
    occurrences: number;
    role?: "background" | "text" | "accent" | "unknown";
  }[];
  fonts: string[];
  headingFontSizePx: number[];
  bodyFontSizePx: number[];
  borderRadiusSamples: string[];
}

export interface SiteAnalysis {
  sourceUrl: string;
  fetchedAt: string;
  title: string;
  metaDescription: string;
  favicon?: string;
  nav: NavLink[];
  footerLinks: NavLink[];
  sections: SectionSummary[];
  images: ImageAsset[];
  designTokens: DesignTokens;
  screenshotBase64?: string; // optional, only populated if a headless browser is available
  rawTextSample: string; // trimmed body text used as a fallback signal
  warnings: string[]; // limitations encountered while analyzing (e.g. no computed styles)
}

export interface GeneratedFile {
  path: string; // relative path inside the generated Next.js project
  content: string;
}

export type AgentLogLevel = "info" | "warn" | "error" | "success" | "step";

export interface AgentLogEntry {
  ts: number;
  level: AgentLogLevel;
  message: string;
}

export type SessionStatus =
  | "idle"
  | "analyzing"
  | "analyzed"
  | "generating"
  | "validating"
  | "fixing"
  | "starting_preview"
  | "ready"
  | "modifying"
  | "error";

export interface AgentSession {
  id: string;
  url: string;
  status: SessionStatus;
  analysis?: SiteAnalysis;
  files: Map<string, string>; // path -> content, current state of the generated project
  projectDir: string;
  previewPort?: number;
  previewProcessPid?: number;
  logs: AgentLogEntry[];
  createdAt: number;
  updatedAt: number;
  fixAttempts: number;
  lastError?: string;
}
