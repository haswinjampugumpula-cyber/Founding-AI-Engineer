import { spawn } from "child_process";
import { getClaudeClient, MODEL, estimateCostUsd } from "./claudeClient";
import { GeneratedFile, SiteAnalysis } from "./types";

export interface CommandResult {
  success: boolean;
  code: number | null;
  output: string;
}

function runCommand(
  cmd: string,
  args: string[],
  cwd: string,
  timeoutMs: number
): Promise<CommandResult> {
  return new Promise((resolve) => {
    const child = spawn(cmd, args, { cwd, shell: process.platform === "win32" });
    let output = "";
    const timer = setTimeout(() => {
      child.kill("SIGKILL");
      output += "\n[timed out]";
      resolve({ success: false, code: null, output });
    }, timeoutMs);

    child.stdout.on("data", (d) => (output += d.toString()));
    child.stderr.on("data", (d) => (output += d.toString()));
    child.on("close", (code) => {
      clearTimeout(timer);
      resolve({ success: code === 0, code, output: output.slice(-8000) });
    });
    child.on("error", (err) => {
      clearTimeout(timer);
      output += `\n[spawn error: ${err.message}]`;
      resolve({ success: false, code: null, output });
    });
  });
}

/** `npm install` in the generated project. Slow but only needs to happen once per session. */
export async function installDependencies(projectDir: string): Promise<CommandResult> {
  return runCommand("npm", ["install", "--no-audit", "--no-fund"], projectDir, 5 * 60 * 1000);
}

/** Fast structural check: TypeScript compiler in noEmit mode. */
export async function typecheckProject(projectDir: string): Promise<CommandResult> {
  return runCommand("npx", ["tsc", "--noEmit", "-p", "tsconfig.json"], projectDir, 2 * 60 * 1000);
}

/** Slower, more thorough check: an actual Next.js production build. */
export async function buildProject(projectDir: string): Promise<CommandResult> {
  return runCommand("npx", ["next", "build"], projectDir, 5 * 60 * 1000);
}

const FIX_FILES_TOOL = {
  name: "write_project_files",
  description:
    "Write the corrected set of files needed to fix the build/typecheck errors. Include the full new content of every file you change.",
  input_schema: {
    type: "object" as const,
    properties: {
      files: {
        type: "array" as const,
        items: {
          type: "object" as const,
          properties: {
            path: { type: "string" as const },
            content: { type: "string" as const },
          },
          required: ["path", "content"],
        },
      },
      explanation: {
        type: "string" as const,
        description: "One or two sentences on what was wrong and how it was fixed.",
      },
    },
    required: ["files"],
  },
};

export interface FixResult {
  files: GeneratedFile[];
  explanation?: string;
  usage: { inputTokens: number; outputTokens: number };
  estimatedCostUsd: number;
}

/**
 * Sends the current generated files (excluding hand-written boilerplate) plus the
 * build/typecheck error output back to Claude and asks for corrected files.
 */
export async function fixFiles(
  analysis: SiteAnalysis,
  currentFiles: GeneratedFile[],
  errorOutput: string
): Promise<FixResult> {
  const client = getClaudeClient();
  const filesBlob = currentFiles
    .map((f) => `--- ${f.path} ---\n${f.content}`)
    .join("\n\n");

  const prompt = `The generated Next.js project (App Router, TypeScript, Tailwind) failed to
build/typecheck. Here are the current AI-generated files (boilerplate like
package.json/next.config.js/layout.tsx is NOT shown because it is hand-written
and not the source of the problem):

${filesBlob}

Build/typecheck error output:
${errorOutput.slice(-6000)}

Site being recreated: ${analysis.sourceUrl}

Fix the problem with the minimum necessary changes. Respond by calling
write_project_files with the corrected full contents of every file you change
(unchanged files can be omitted).`;

  const response = await client.messages.create({
    model: MODEL,
    max_tokens: 8000,
    system:
      "You are a senior TypeScript/Next.js engineer fixing build errors in an AI-generated Next.js App Router project. Be precise and minimal.",
    tools: [FIX_FILES_TOOL],
    tool_choice: { type: "tool", name: "write_project_files" },
    messages: [{ role: "user", content: prompt }],
  });

  const toolUse = response.content.find((b) => b.type === "tool_use");
  if (!toolUse || toolUse.type !== "tool_use") {
    throw new Error("Model did not return a write_project_files tool call while fixing.");
  }
  const input = toolUse.input as { files: GeneratedFile[]; explanation?: string };
  const usage = {
    inputTokens: response.usage.input_tokens,
    outputTokens: response.usage.output_tokens,
  };

  return {
    files: input.files,
    explanation: input.explanation,
    usage,
    estimatedCostUsd: estimateCostUsd(usage),
  };
}
