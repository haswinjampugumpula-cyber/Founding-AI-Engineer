import axios from "axios";
import * as cheerio from "cheerio";
import {
  DesignTokens,
  ImageAsset,
  NavLink,
  SectionSummary,
  SiteAnalysis,
} from "./types";

const USER_AGENT =
  "Mozilla/5.0 (compatible; WebsiteClonerAgent/1.0; +https://example.com/bot)";

const MAX_SECTIONS = 14;
const MAX_TEXT_CHARS = 600;
const MAX_IMAGES = 24;

/**
 * Fetches the raw HTML (and same-origin <link rel="stylesheet"> CSS, best effort)
 * for a public URL. No headless browser is used here, so this only sees the
 * server-rendered HTML/CSS — client-side-rendered (SPA) content and computed
 * styles are not visible. That limitation is recorded in `warnings` so it is
 * surfaced to the user and to the code-generation prompt.
 */
export async function fetchSite(url: string): Promise<{
  html: string;
  finalUrl: string;
  stylesheets: string[];
  warnings: string[];
}> {
  const warnings: string[] = [];
  const res = await axios.get(url, {
    headers: { "User-Agent": USER_AGENT, Accept: "text/html,*/*" },
    timeout: 15000,
    maxRedirects: 5,
    validateStatus: (s) => s < 500,
  });

  if (res.status >= 400) {
    warnings.push(
      `Site responded with HTTP ${res.status}; analysis may be incomplete.`
    );
  }

  const html: string = typeof res.data === "string" ? res.data : String(res.data);
  const finalUrl: string = res.request?.res?.responseUrl || url;

  const $ = cheerio.load(html);
  const stylesheetLinks = $('link[rel="stylesheet"]')
    .map((_, el) => $(el).attr("href"))
    .get()
    .filter(Boolean) as string[];

  const stylesheets: string[] = [];
  const toFetch = stylesheetLinks.slice(0, 5); // cap external CSS fetches
  for (const href of toFetch) {
    try {
      const abs = new URL(href, finalUrl).toString();
      const cssRes = await axios.get(abs, {
        headers: { "User-Agent": USER_AGENT },
        timeout: 8000,
        validateStatus: (s) => s < 500,
      });
      if (typeof cssRes.data === "string") {
        stylesheets.push(cssRes.data.slice(0, 60000)); // cap size per file
      }
    } catch {
      warnings.push(`Could not fetch stylesheet: ${href}`);
    }
  }

  if (stylesheetLinks.length > toFetch.length) {
    warnings.push(
      `Only fetched ${toFetch.length} of ${stylesheetLinks.length} linked stylesheets to keep analysis fast.`
    );
  }

  return { html, finalUrl, stylesheets, warnings };
}

function absolutize(base: string, maybeUrl?: string | null): string {
  if (!maybeUrl) return "";
  try {
    return new URL(maybeUrl, base).toString();
  } catch {
    return maybeUrl;
  }
}

function extractNav($: cheerio.CheerioAPI, baseUrl: string): NavLink[] {
  const links: NavLink[] = [];
  const seen = new Set<string>();
  $("header nav a, nav a").each((_, el) => {
    const text = $(el).text().trim().replace(/\s+/g, " ");
    const href = absolutize(baseUrl, $(el).attr("href"));
    if (!text || !href || seen.has(text + href)) return;
    seen.add(text + href);
    links.push({ text, href });
  });
  return links.slice(0, 20);
}

function extractFooterLinks($: cheerio.CheerioAPI, baseUrl: string): NavLink[] {
  const links: NavLink[] = [];
  const seen = new Set<string>();
  $("footer a").each((_, el) => {
    const text = $(el).text().trim().replace(/\s+/g, " ");
    const href = absolutize(baseUrl, $(el).attr("href"));
    if (!text || !href || seen.has(text + href)) return;
    seen.add(text + href);
    links.push({ text, href });
  });
  return links.slice(0, 20);
}

function extractSections($: cheerio.CheerioAPI): SectionSummary[] {
  const candidates = $(
    "body header, body > section, body main section, body main > *, body footer, main"
  ).toArray();

  // Deduplicate while preserving order; prefer semantic top-level blocks.
  const picked: cheerio.Element[] = [];
  const seenEls = new Set<cheerio.Element>();
  for (const el of candidates) {
    if (seenEls.has(el)) continue;
    seenEls.add(el);
    picked.push(el);
    if (picked.length >= MAX_SECTIONS * 2) break;
  }

  const summaries: SectionSummary[] = [];
  for (const el of picked) {
    const node = $(el);
    const tag = (el as any).tagName || (el as any).name || "section";
    const heading = node.find("h1,h2,h3").first();
    const text = node
      .clone()
      .find("script,style,nav")
      .remove()
      .end()
      .text()
      .replace(/\s+/g, " ")
      .trim()
      .slice(0, MAX_TEXT_CHARS);

    if (!text && node.find("img").length === 0) continue;

    const imageAlts = node
      .find("img")
      .map((_, img) => $(img).attr("alt") || "")
      .get()
      .filter(Boolean)
      .slice(0, 8);

    const buttonLabels = node
      .find("button, a.btn, a[class*='button'], [role='button']")
      .map((_, b) => $(b).text().trim())
      .get()
      .filter(Boolean)
      .slice(0, 8);

    summaries.push({
      tag: String(tag).toLowerCase(),
      heading: heading.text().trim() || undefined,
      headingLevel: heading.length
        ? Number(String((heading.get(0) as any)?.tagName || "h2").replace(/\D/g, "")) || 2
        : undefined,
      text,
      imageCount: node.find("img").length,
      imageAlts,
      hasForm: node.find("form").length > 0,
      listItemCount: node.find("li").length,
      buttonLabels,
    });

    if (summaries.length >= MAX_SECTIONS) break;
  }
  return summaries;
}

function extractImages($: cheerio.CheerioAPI, baseUrl: string): ImageAsset[] {
  const images: ImageAsset[] = [];
  $("img").each((_, el) => {
    if (images.length >= MAX_IMAGES) return;
    const node = $(el);
    const src = absolutize(
      baseUrl,
      node.attr("src") || node.attr("data-src") || node.attr("srcset")?.split(" ")[0]
    );
    if (!src) return;
    images.push({
      src,
      alt: node.attr("alt") || "",
      width: Number(node.attr("width")) || undefined,
      height: Number(node.attr("height")) || undefined,
    });
  });
  return images;
}

const HEX_COLOR_RE = /#(?:[0-9a-fA-F]{3}){1,2}\b/g;
const RGB_COLOR_RE = /rgba?\(\s*\d+\s*,\s*\d+\s*,\s*\d+\s*(?:,\s*[\d.]+\s*)?\)/g;

function rgbToHex(rgb: string): string | null {
  const m = rgb.match(/\d+/g);
  if (!m || m.length < 3) return null;
  const [r, g, b] = m.map(Number);
  return (
    "#" +
    [r, g, b]
      .map((v) => Math.max(0, Math.min(255, v)).toString(16).padStart(2, "0"))
      .join("")
  );
}

function extractDesignTokens(
  html: string,
  stylesheets: string[],
  $: cheerio.CheerioAPI
): DesignTokens {
  const cssBlob =
    stylesheets.join("\n") +
    "\n" +
    $("style")
      .map((_, el) => $(el).html() || "")
      .get()
      .join("\n") +
    "\n" +
    $("[style]")
      .map((_, el) => $(el).attr("style") || "")
      .get()
      .join(";");

  const colorCounts = new Map<string, number>();
  const hexMatches = cssBlob.match(HEX_COLOR_RE) || [];
  const rgbMatches = cssBlob.match(RGB_COLOR_RE) || [];

  for (const raw of hexMatches) {
    const hex = raw.length === 4
      ? "#" + raw.slice(1).split("").map((c) => c + c).join("")
      : raw.toLowerCase();
    colorCounts.set(hex, (colorCounts.get(hex) || 0) + 1);
  }
  for (const raw of rgbMatches) {
    const hex = rgbToHex(raw);
    if (hex) colorCounts.set(hex, (colorCounts.get(hex) || 0) + 1);
  }

  // Drop pure black/white if they dominate trivially and there are richer colors,
  // but still keep them available — just deprioritized by natural sort below.
  const colors = Array.from(colorCounts.entries())
    .map(([hex, occurrences]) => ({ hex, occurrences }))
    .sort((a, b) => b.occurrences - a.occurrences)
    .slice(0, 12);

  const fontFamilyRe = /font-family\s*:\s*([^;"'}]+)/gi;
  const fonts = new Set<string>();
  let fm: RegExpExecArray | null;
  while ((fm = fontFamilyRe.exec(cssBlob))) {
    const family = fm[1].split(",")[0].trim().replace(/["']/g, "");
    if (family && family.length < 40) fonts.add(family);
    if (fonts.size >= 8) break;
  }

  const fontSizeRe = /font-size\s*:\s*(\d+(?:\.\d+)?)px/gi;
  const sizes: number[] = [];
  let sm: RegExpExecArray | null;
  while ((sm = fontSizeRe.exec(cssBlob)) && sizes.length < 60) {
    sizes.push(parseFloat(sm[1]));
  }
  const headingFontSizePx = Array.from(new Set(sizes.filter((s) => s >= 22))).sort(
    (a, b) => b - a
  ).slice(0, 6);
  const bodyFontSizePx = Array.from(new Set(sizes.filter((s) => s < 22))).sort(
    (a, b) => a - b
  ).slice(0, 6);

  const radiusRe = /border-radius\s*:\s*([^;"'}]+)/gi;
  const radii = new Set<string>();
  let rm: RegExpExecArray | null;
  while ((rm = radiusRe.exec(cssBlob)) && radii.size < 6) {
    radii.add(rm[1].trim());
  }

  return {
    colors,
    fonts: Array.from(fonts),
    headingFontSizePx,
    bodyFontSizePx,
    borderRadiusSamples: Array.from(radii),
  };
}

/**
 * Top-level entry point: fetch + parse a public URL into a structured
 * SiteAnalysis object that the code-generation step can reason about.
 */
export async function analyzeSite(url: string): Promise<SiteAnalysis> {
  const { html, finalUrl, stylesheets, warnings } = await fetchSite(url);
  const $ = cheerio.load(html);

  const title = $("title").first().text().trim() || finalUrl;
  const metaDescription =
    $('meta[name="description"]').attr("content")?.trim() || "";
  const favicon = absolutize(
    finalUrl,
    $('link[rel="icon"]').attr("href") || $('link[rel="shortcut icon"]').attr("href")
  );

  const nav = extractNav($, finalUrl);
  const footerLinks = extractFooterLinks($, finalUrl);
  const sections = extractSections($);
  const images = extractImages($, finalUrl);
  const designTokens = extractDesignTokens(html, stylesheets, $);

  const rawTextSample = $("body")
    .clone()
    .find("script,style,noscript")
    .remove()
    .end()
    .text()
    .replace(/\s+/g, " ")
    .trim()
    .slice(0, 4000);

  const allWarnings = [...warnings];
  allWarnings.push(
    "Static HTML/CSS analysis only: no headless browser was used, so client-side-rendered content and computed (post-JS) styles are not captured. Heavily JS-driven SPAs will analyze poorly."
  );
  if (sections.length === 0) {
    allWarnings.push(
      "No clear semantic sections were found; the page may rely on non-semantic markup or client-side rendering."
    );
  }
  if (designTokens.colors.length === 0) {
    allWarnings.push(
      "No colors could be extracted from inline styles or linked stylesheets."
    );
  }

  return {
    sourceUrl: finalUrl,
    fetchedAt: new Date().toISOString(),
    title,
    metaDescription,
    favicon: favicon || undefined,
    nav,
    footerLinks,
    sections,
    images,
    designTokens,
    rawTextSample,
    warnings: allWarnings,
  };
}
