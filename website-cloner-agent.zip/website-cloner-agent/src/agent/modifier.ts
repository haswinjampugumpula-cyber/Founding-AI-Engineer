import { getClaudeClient, MODEL, estimateCostUsd } from "./claudeClient";
import { GeneratedFile, SiteAnalysis } from "./types";

const MODIFY_TOOL = {
  name: "write_project_files",
  description:
    "Write the updated set of files that implement the requested change. Include the full new content of every file you add or change; omit files that don't change.",
  input_schema: {
    type: "object" as const,
    properties: {
      files: {
        type: "array" as const,
        items: {
          type: "object" as const,
          properties: {
            path: { type: "string" as const },
            content: { type: "string" as const },
          },
          required: ["path", "content"],
        },
      },
      summary: {
        type: "string" as const,
        description: "One or two sentences summarizing what changed.",
      },
    },
    required: ["files"],
  },
};

export interface ModifyResult {
  files: GeneratedFile[];
  summary?: string;
  usage: { inputTokens: number; outputTokens: number };
  estimatedCostUsd: number;
}

/**
 * Applies a single natural-language instruction (e.g. "make the navbar sticky",
 * "add a testimonials section", "change the primary color to blue") to the
 * current generated project.
 */
export async function applyModification(
  analysis: SiteAnalysis | undefined,
  currentFiles: GeneratedFile[],
  instruction: string
): Promise<ModifyResult> {
  const client = getClaudeClient();
  const filesBlob = currentFiles
    .map((f) => `--- ${f.path} ---\n${f.content}`)
    .join("\n\n");

  const context = analysis
    ? `Original site being recreated: ${analysis.sourceUrl} ("${analysis.title}")`
    : "";

  const prompt = `${context}

Current generated Next.js (App Router, TypeScript, Tailwind) project files
(hand-written boilerplate such as package.json/next.config.js/layout.tsx is
omitted since it should not need to change for a UI edit):

${filesBlob}

User's requested change, in their own words:
"${instruction}"

Apply this change with the minimum necessary edits, keeping the rest of the
site intact. Follow the same conventions already used in the project (Tailwind
utility classes with arbitrary-value colors, small reusable components, Server
Components by default, "use client" only where genuinely needed). If the
instruction is ambiguous, make the most reasonable interpretation and note any
assumptions in the summary.

Respond by calling write_project_files with the full contents of every file
you add or change.`;

  const response = await client.messages.create({
    model: MODEL,
    max_tokens: 8000,
    system:
      "You are a senior frontend engineer editing an existing AI-generated Next.js site based on a plain-English instruction from the site owner.",
    tools: [MODIFY_TOOL],
    tool_choice: { type: "tool", name: "write_project_files" },
    messages: [{ role: "user", content: prompt }],
  });

  const toolUse = response.content.find((b) => b.type === "tool_use");
  if (!toolUse || toolUse.type !== "tool_use") {
    throw new Error("Model did not return a write_project_files tool call while modifying.");
  }
  const input = toolUse.input as { files: GeneratedFile[]; summary?: string };
  const usage = {
    inputTokens: response.usage.input_tokens,
    outputTokens: response.usage.output_tokens,
  };

  return {
    files: input.files,
    summary: input.summary,
    usage,
    estimatedCostUsd: estimateCostUsd(usage),
  };
}
