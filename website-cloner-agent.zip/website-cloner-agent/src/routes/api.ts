import { Router } from "express";
import {
  runAnalysis,
  runFullBuildCheck,
  runGeneration,
  runModification,
  teardownSession,
} from "../agent/orchestrator";
import { createSession, getSession, listSessions, log } from "../agent/session";
import { AgentSession } from "../agent/types";

export const apiRouter = Router();

function serializeSession(session: AgentSession) {
  return {
    id: session.id,
    url: session.url,
    status: session.status,
    createdAt: session.createdAt,
    updatedAt: session.updatedAt,
    previewPort: session.previewPort,
    fixAttempts: session.fixAttempts,
    lastError: session.lastError,
    analysis: session.analysis
      ? {
          sourceUrl: session.analysis.sourceUrl,
          title: session.analysis.title,
          metaDescription: session.analysis.metaDescription,
          nav: session.analysis.nav,
          footerLinks: session.analysis.footerLinks,
          sectionCount: session.analysis.sections.length,
          sections: session.analysis.sections,
          imageCount: session.analysis.images.length,
          designTokens: session.analysis.designTokens,
          warnings: session.analysis.warnings,
        }
      : undefined,
    fileList: Array.from(session.files.keys()),
    logs: session.logs,
  };
}

// Create a session and run analysis (fast: HTTP fetch + HTML parse only).
apiRouter.post("/sessions", async (req, res) => {
  const url: string = (req.body?.url || "").trim();
  if (!url || !/^https?:\/\//i.test(url)) {
    return res.status(400).json({ error: "Provide a valid http(s) URL." });
  }
  const session = createSession(url);
  try {
    await runAnalysis(session);
    res.status(201).json(serializeSession(session));
  } catch (err: any) {
    res.status(200).json(serializeSession(session)); // session still exists; error is in logs/status
  }
});

apiRouter.get("/sessions", (_req, res) => {
  res.json(listSessions().map(serializeSession));
});

apiRouter.get("/sessions/:id", (req, res) => {
  const session = getSession(req.params.id);
  if (!session) return res.status(404).json({ error: "Session not found." });
  res.json(serializeSession(session));
});

// Kick off code generation + validation + preview launch in the background.
apiRouter.post("/sessions/:id/generate", async (req, res) => {
  const session = getSession(req.params.id);
  if (!session) return res.status(404).json({ error: "Session not found." });
  if (session.status === "generating" || session.status === "validating") {
    return res.status(409).json({ error: "Generation already in progress." });
  }
  res.status(202).json({ accepted: true });
  runGeneration(session).catch((err) => {
    log(session, "error", `Generation pipeline failed: ${err.message}`);
  });
});

// Optional slower full `next build` check, run on demand.
apiRouter.post("/sessions/:id/build-check", async (req, res) => {
  const session = getSession(req.params.id);
  if (!session) return res.status(404).json({ error: "Session not found." });
  res.status(202).json({ accepted: true });
  runFullBuildCheck(session).catch((err) => {
    log(session, "error", `Build check failed: ${err.message}`);
  });
});

// Apply a natural-language modification instruction.
apiRouter.post("/sessions/:id/modify", async (req, res) => {
  const session = getSession(req.params.id);
  if (!session) return res.status(404).json({ error: "Session not found." });
  const instruction: string = (req.body?.instruction || "").trim();
  if (!instruction) return res.status(400).json({ error: "Provide an instruction." });
  if (session.status !== "ready") {
    return res.status(409).json({ error: "Session is not ready for modification yet." });
  }
  res.status(202).json({ accepted: true });
  runModification(session, instruction).catch((err) => {
    log(session, "error", `Modification failed: ${err.message}`);
  });
});

apiRouter.delete("/sessions/:id", async (req, res) => {
  const session = getSession(req.params.id);
  if (!session) return res.status(404).json({ error: "Session not found." });
  await teardownSession(session);
  res.json({ ok: true });
});
