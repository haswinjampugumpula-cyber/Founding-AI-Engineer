import "dotenv/config";
import path from "path";
import express from "express";
import cors from "cors";
import fs from "fs-extra";
import { apiRouter } from "./routes/api";
import { stopAllPreviews } from "./agent/previewManager";

const app = express();
const PORT = Number(process.env.PORT || 4000);

app.use(cors());
app.use(express.json({ limit: "5mb" }));
app.use(express.static(path.join(__dirname, "..", "public")));
app.use("/api", apiRouter);

app.get("/health", (_req, res) => res.json({ ok: true }));

async function main() {
  await fs.ensureDir(path.join(__dirname, "..", "generated-sites"));

  if (!process.env.ANTHROPIC_API_KEY) {
    // eslint-disable-next-line no-console
    console.warn(
      "\n⚠️  ANTHROPIC_API_KEY is not set. Copy .env.example to .env and add your key before generating sites.\n"
    );
  }

  app.listen(PORT, () => {
    // eslint-disable-next-line no-console
    console.log(`\nWebsite Cloner Agent control panel running at http://localhost:${PORT}\n`);
  });
}

process.on("SIGINT", () => {
  stopAllPreviews();
  process.exit(0);
});
process.on("SIGTERM", () => {
  stopAllPreviews();
  process.exit(0);
});

main();
