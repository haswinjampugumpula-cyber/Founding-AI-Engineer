import type { Config } from "tailwindcss";

const config: Config = {
  content: ["./app/**/*.{ts,tsx}", "./components/**/*.{ts,tsx}"],
  theme: {
    extend: {
      colors: {
        // __GENERATED_COLOR_TOKENS__
      },
      fontFamily: {
        // __GENERATED_FONT_TOKENS__
      },
    },
  },
  plugins: [],
};
export default config;
