This directory is the *base scaffold* copied into every generated site
(generated-sites/<session-id>/). The code-generation step (src/agent/codegen.ts)
fills in app/page.tsx, app/components/*.tsx, app/globals.css color tokens, and
patches tailwind.config.ts with the extracted design tokens. Keeping the
boilerplate (package.json, next.config.js, tsconfig.json, postcss/tailwind
config, layout shell) hand-written rather than AI-generated makes every build
more reliable and cheaper, since Claude only needs to generate the actual UI
code, not framework plumbing it could get subtly wrong.
