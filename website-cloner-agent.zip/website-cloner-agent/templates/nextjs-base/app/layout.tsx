import type { Metadata } from "next";
import "./globals.css";

export const metadata: Metadata = {
  title: "__SITE_TITLE__",
  description: "__SITE_DESCRIPTION__",
};

export default function RootLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <html lang="en">
      <body>{children}</body>
    </html>
  );
}
