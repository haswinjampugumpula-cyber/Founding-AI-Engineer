# Architecture

## Pipeline overview

```mermaid
flowchart TD
    A[User enters URL in control panel] --> B[POST /api/sessions]
    B --> C[scraper.ts: fetch HTML + linked CSS]
    C --> D[scraper.ts: extract nav, sections,\nimages, colors, fonts -> SiteAnalysis]
    D --> E[POST /api/sessions/:id/generate]
    E --> F[codegen.ts: scaffold hand-written\nNext.js/Tailwind boilerplate]
    F --> G[codegen.ts: Claude tool-call\nwrite_project_files -> page + components]
    G --> H[validator.ts: npm install]
    H --> I[validator.ts: tsc --noEmit]
    I -->|fails| J[validator.ts: fixFiles\nsend errors back to Claude]
    J --> I
    I -->|passes or attempts exhausted| K[previewManager.ts: spawn\nnext dev on an allocated port]
    K --> L[Iframe in control panel\npoints at http://localhost:PORT]
    L --> M[User types a natural-language\nedit in the chat box]
    M --> N[POST /api/sessions/:id/modify]
    N --> O[modifier.ts: Claude edits the\nrelevant files, minimal diff]
    O --> I
```

## Components

| File | Responsibility |
| --- | --- |
| `src/agent/scraper.ts` | Fetches the target URL and up to 5 linked stylesheets with `axios`, parses the DOM with `cheerio`, and extracts a structured `SiteAnalysis`: nav links, footer links, up to 14 top-level sections (heading, text, image alts, buttons, forms), up to 24 images, and design tokens (color frequency table from hex/rgb values in inline styles + `<style>` + linked CSS, font-family names, heading/body font sizes, border-radius samples). |
| `src/agent/codegen.ts` | Copies the hand-written base Next.js scaffold (`templates/nextjs-base`) into a fresh `generated-sites/<sessionId>/` directory, then calls Claude with a forced `write_project_files` tool call to generate `app/page.tsx`, `app/components/*.tsx`, and `app/globals.css` from the `SiteAnalysis`. |
| `src/agent/validator.ts` | Runs `npm install`, then `tsc --noEmit` (fast structural check) in the generated project. On failure, sends the AI-generated files + the compiler output back to Claude via another forced tool call and asks for a minimal fix; loops up to `MAX_FIX_ATTEMPTS`. A slower, optional `next build` check is also exposed. |
| `src/agent/modifier.ts` | Takes a single natural-language instruction plus the current generated files and asks Claude for the minimal file changes that implement it, reusing the same tool-call contract as `codegen.ts`. |
| `src/agent/previewManager.ts` | Allocates a free port from `PREVIEW_PORT_RANGE_START` upward and spawns `next dev -p <port>` for a session's generated project, tracking the child process so it can be killed/replaced. |
| `src/agent/session.ts` | In-memory session store: id, URL, status machine, analysis, current file map, structured logs, preview port. |
| `src/agent/orchestrator.ts` | Wires the above into the four pipeline stages (analyze / generate+validate+fix / launch preview / modify), updating session status and logs at each step. |
| `src/routes/api.ts` + `src/server.ts` | Express HTTP layer + static file server for the control-panel UI. Long-running steps (generate, modify) return `202 Accepted` immediately; the UI polls `GET /api/sessions/:id` for status/log updates. |
| `public/` | Plain HTML/CSS/vanilla JS control panel (no build step) — URL input, analysis summary with color swatches, live log console, the generated site inside an iframe with desktop/tablet/mobile width toggles, and a modification chat box. |
| `templates/nextjs-base/` | Hand-written Next.js 14 App Router + TypeScript + Tailwind boilerplate (`package.json`, `next.config.js`, `tsconfig.json`, `tailwind.config.ts`, `postcss.config.js`, `app/layout.tsx`). Kept out of the AI generation loop deliberately — see "Key implementation decisions" in the README. |

## Why this split of "the tool" vs. "the generated output"

The **orchestrator/control panel** (this repository's own server + UI) is a plain
Express + vanilla JS app — it does not itself need to be React/Next.js, so it
was kept as simple and dependency-light as possible.

The **generated output** — what the assignment actually grades — is a real,
separate Next.js/TypeScript/Tailwind project per session, written to
`generated-sites/<sessionId>/`, installable and runnable on its own
(`cd generated-sites/<id> && npm install && npm run dev`), independent of the
orchestrator that created it.
