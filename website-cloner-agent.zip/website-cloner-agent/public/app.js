const state = {
  sessionId: null,
  lastLogCount: 0,
  pollTimer: null,
  previewLoaded: false,
};

const el = (id) => document.getElementById(id);

const urlInput = el("url-input");
const analyzeBtn = el("analyze-btn");
const generateBtn = el("generate-btn");
const statusBar = el("status-bar");
const analysisPanel = el("analysis-panel");
const analysisSummary = el("analysis-summary");
const colorSwatches = el("color-swatches");
const logConsole = el("log-console");
const modifyInput = el("modify-input");
const modifyBtn = el("modify-btn");
const previewFrame = el("preview-iframe");
const previewPlaceholder = el("preview-placeholder");
const previewUrlLabel = el("preview-url-label");
const previewWrap = el("preview-frame-wrap");
const refreshBtn = el("refresh-btn");

function setStatus(text) {
  statusBar.textContent = text;
}

function appendLogs(logs) {
  for (const entry of logs) {
    const div = document.createElement("div");
    div.className = `log-${entry.level}`;
    const time = new Date(entry.ts).toLocaleTimeString();
    div.textContent = `[${time}] ${entry.message}`;
    logConsole.appendChild(div);
  }
  logConsole.scrollTop = logConsole.scrollHeight;
}

function renderAnalysis(analysis) {
  if (!analysis) return;
  analysisPanel.classList.remove("hidden");
  analysisSummary.innerHTML = `
    <div><span class="text-slate-500">Title:</span> ${escapeHtml(analysis.title)}</div>
    <div><span class="text-slate-500">Sections found:</span> ${analysis.sectionCount}</div>
    <div><span class="text-slate-500">Images found:</span> ${analysis.imageCount}</div>
    <div><span class="text-slate-500">Nav links:</span> ${analysis.nav.length}</div>
  `;
  colorSwatches.innerHTML = "";
  for (const c of analysis.designTokens.colors.slice(0, 10)) {
    const sw = document.createElement("div");
    sw.title = `${c.hex} (${c.occurrences}x)`;
    sw.style.background = c.hex;
    sw.className = "w-6 h-6 rounded border border-slate-700";
    colorSwatches.appendChild(sw);
  }
}

function escapeHtml(s) {
  return (s || "").replace(/[&<>"']/g, (c) => ({
    "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;",
  }[c]));
}

const STATUS_LABELS = {
  idle: "Idle",
  analyzing: "Analyzing website…",
  analyzed: "Analysis complete — ready to generate",
  generating: "Generating frontend with Claude…",
  validating: "Type-checking generated code…",
  fixing: "Auto-fixing build errors…",
  starting_preview: "Starting local preview server…",
  ready: "✅ Preview ready",
  modifying: "Applying your modification…",
  error: "❌ Error — see log",
};

async function pollSession() {
  if (!state.sessionId) return;
  const res = await fetch(`/api/sessions/${state.sessionId}`);
  if (!res.ok) return;
  const session = await res.json();

  setStatus(STATUS_LABELS[session.status] || session.status);
  renderAnalysis(session.analysis);

  if (session.logs.length > state.lastLogCount) {
    appendLogs(session.logs.slice(state.lastLogCount));
    state.lastLogCount = session.logs.length;
  }

  const busy = ["analyzing", "generating", "validating", "fixing", "starting_preview", "modifying"].includes(
    session.status
  );
  generateBtn.disabled = busy || !session.analysis || session.status === "ready" || session.status === "generating";
  modifyInput.disabled = session.status !== "ready";
  modifyBtn.disabled = session.status !== "ready";

  if (session.status === "ready" && session.previewPort) {
    const previewUrl = `http://localhost:${session.previewPort}`;
    previewUrlLabel.textContent = previewUrl;
    if (!state.previewLoaded || previewFrame.dataset.port !== String(session.previewPort)) {
      previewFrame.src = previewUrl;
      previewFrame.dataset.port = String(session.previewPort);
      previewFrame.classList.remove("hidden");
      previewPlaceholder.classList.add("hidden");
      state.previewLoaded = true;
    }
  }
}

function startPolling() {
  if (state.pollTimer) clearInterval(state.pollTimer);
  state.pollTimer = setInterval(pollSession, 1500);
  pollSession();
}

analyzeBtn.addEventListener("click", async () => {
  const url = urlInput.value.trim();
  if (!url) return;
  analyzeBtn.disabled = true;
  generateBtn.disabled = true;
  logConsole.innerHTML = "";
  state.lastLogCount = 0;
  state.previewLoaded = false;
  previewFrame.classList.add("hidden");
  previewPlaceholder.classList.remove("hidden");
  setStatus("Creating session and analyzing…");

  try {
    const res = await fetch("/api/sessions", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ url }),
    });
    const session = await res.json();
    state.sessionId = session.id;
    state.lastLogCount = 0;
    appendLogs(session.logs);
    state.lastLogCount = session.logs.length;
    renderAnalysis(session.analysis);
    generateBtn.disabled = session.status === "error";
    startPolling();
  } catch (err) {
    setStatus("Failed to reach the agent server.");
  } finally {
    analyzeBtn.disabled = false;
  }
});

generateBtn.addEventListener("click", async () => {
  if (!state.sessionId) return;
  generateBtn.disabled = true;
  await fetch(`/api/sessions/${state.sessionId}/generate`, { method: "POST" });
  startPolling();
});

modifyBtn.addEventListener("click", sendModification);
modifyInput.addEventListener("keydown", (e) => {
  if (e.key === "Enter") sendModification();
});

async function sendModification() {
  const instruction = modifyInput.value.trim();
  if (!instruction || !state.sessionId) return;
  modifyInput.value = "";
  modifyBtn.disabled = true;
  await fetch(`/api/sessions/${state.sessionId}/modify`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ instruction }),
  });
}

refreshBtn.addEventListener("click", () => {
  if (previewFrame.src) previewFrame.src = previewFrame.src;
});

document.querySelectorAll(".viewport-btn").forEach((btn) => {
  btn.addEventListener("click", () => {
    document.querySelectorAll(".viewport-btn").forEach((b) => b.classList.remove("active-viewport"));
    btn.classList.add("active-viewport");
    previewWrap.style.width = btn.dataset.w;
  });
});
